<?php
# db configuration 
define('DB_HOST',		'mysql.brushup.me');
define('DB_USER',		'brushup13');
define('DB_PASS',		'*?U2c!Ri');
define('DB_NAME',		'brushup_db');

# db connect
function dbConnect($close=true){
	global $link;

	if (!$close) {
		mysql_close($link);
		return true;
	}

	$link = mysql_connect(DB_HOST, DB_USER, DB_PASS) or die('Could not connect to MySQL DB ') . mysql_error();
	if (!mysql_select_db(DB_NAME, $link))
		return false;
}

?>