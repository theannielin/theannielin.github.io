<?php
		$array2 = [];
			    file_put_contents($_POST['path'], "", FILE_APPEND);
                $handle = fopen($_POST['path'], "r");
                $count = 0;
                if ($handle) {
                    while (($line = fgets($handle)) !== false) {
                        $count ++;
                        if ($count % 8 == 0)
                        {
                            continue;
                        }
                        else
                        {
                            array_push($array2, trim($line));
                        }
                        
                    }
                } else {
                    // error opening the file.
                }
                
                echo json_encode($array2);        
?>
