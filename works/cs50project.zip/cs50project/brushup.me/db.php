<?php
        //Edit this code with your database credentials
        $link = mysql_connect('mysql.brushup.me', 'brushup13', '*?U2c!Ri'); 
        if (!$link) { 
                die('Could not connect: ' . mysql_error()); 
        } 
        mysql_select_db('test', $link); 
?>