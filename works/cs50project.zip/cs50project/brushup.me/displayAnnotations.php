<?php

$array = json_decode(file_get_contents('annotation.json'), true);
echo $array;

?>

