var $j = jQuery.noConflict();
$j(document).ready(function() {
	
	// Expand Panel
	$j("#open").click(function(){
		$j("div#panel").slideDown("slow");
	
	});	
	
	// Collapse Panel
	$j("#close").click(function(){
		$j("div#panel").slideUp("slow");	
	});		
	
	// Switch buttons from "Log In | Register" to "Close Panel" on click
	$j("#toggle a").click(function () {
		$j("#toggle a").toggle();
	});		
		
});
