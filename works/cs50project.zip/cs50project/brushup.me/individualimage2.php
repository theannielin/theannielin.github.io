else
	    {  
	       $dirpath = "/home/brushup13/brushup.me/users/";
	       if ($handle = opendir($dirpath.$_SESSION['usr'])) 
	       {    
		    while (false !== ($entry = readdir($handle)))
		    {
			
			if (!is_dir($dirpath.$_SESSION['usr']."/".$entry))
			{
			    if ($entry != "." && $entry != "..")
			    {
				
				echo "<div class='box'>";
				
				
				$entry = str_replace(" ", "%20", $entry);
				
				//echo "$entry"."<br>";
				 
				$titleofpic = mysql_query(
				'SELECT title, photo
				FROM uppho') or die(mysql_error());
				
				while($row=mysql_fetch_array($titleofpic))
				{
				if ($row['photo']==$entry)
				{
				echo "<div style='color: #363636; font-size: 40px; padding-left:30px; text-align: left; font-family:palatino;'>&nbsp".$row['title']."</div>";
				
				echo "<img style='width:600px; display: block; margin-left: auto; margin-right: auto;' src=http://www.brushup.me/users/".$_SESSION['usr']."/".$entry." ><br>";
				}
				
				}
				echo "</div>";
			    }
			}
		    }
		}
		echo "<br>";
	    }
	    ?>
	    
    </div>
    <p style="text-align:center; margin-top: 20px">&copy chillandawg</p>
</div>


</body>

</html>