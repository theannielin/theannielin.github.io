<?php

foreach($_POST['annotations'] as $v1)
{
    foreach($v1 as $v2)
    {
        if(is_array($v2))
        {
            foreach($v2 as $v3)
            {
                if(is_array($v3))
                {
                    foreach($v3 as $v4)
                    {
                        if (is_array($v4))
                        {
                            foreach($v4 as $v5)
                            {
                                file_put_contents($_POST['path'], $v5, FILE_APPEND);
                                file_put_contents($_POST['path'], "\n", FILE_APPEND);
                            }
                        
                        }
                        else
                        {

                            file_put_contents($_POST['path'], $v4, FILE_APPEND);
                            file_put_contents($_POST['path'], "\n", FILE_APPEND);
                        }
                     
                    }
                }
                else
                {
                    file_put_contents($_POST['path'], $v3, FILE_APPEND);
                    file_put_contents($_POST['path'], "\n", FILE_APPEND);
                }
            }
        }
        else
        {

                file_put_contents($_POST['path'], $v2, FILE_APPEND);
                file_put_contents($_POST['path'], "\n", FILE_APPEND);


        }
                
    }

}


// var_dump($_POST['annotations']);

/*$array = [[0,1],[1,2],[3,4]];
foreach($array as $value)
{
    foreach($value as $annot)
    {
        print_r($annot);
    }
}
*/
?>

