<?php
    define('INCLUDE_CHECK',true);
    require 'functions.php';
    
    session_name('tzLogin');
    session_set_cookie_params(2*7*24*60*60);
    session_start();
    
    if (!($_SESSION["id"]))
    {
        echo "You need to login first.";
    }
    else
    {
    
        $allowedExts = array("gif", "jpeg", "jpg", "png");
        $temp = explode(".", $_FILES["file"]["name"]);
        $extension = end($temp);
        
        if ((($_FILES["file"]["type"] == "image/gif")
        || ($_FILES["file"]["type"] == "image/jpeg")
        || ($_FILES["file"]["type"] == "image/jpg")
        || ($_FILES["file"]["type"] == "image/pjpeg")
        || ($_FILES["file"]["type"] == "image/x-png")
        || ($_FILES["file"]["type"] == "image/png"))
        && ($_FILES["file"]["size"] < 200000)
        && in_array($extension, $allowedExts))
          {
            if ($_FILES["file"]["error"] > 0)
            {
                echo "Return Code: " . $_FILES["file"]["error"] . "<br>";
            }
            else
            {
            //echo "Upload: " . $_FILES["file"]["name"] . "<br>";
            //echo "Type: " . $_FILES["file"]["type"] . "<br>";
            //echo "Size: " . ($_FILES["file"]["size"] / 1024) . " kB<br>";
            //echo "Temp file: " . $_FILES["file"]["tmp_name"] . "<br>";

                if (file_exists("users/".$_SESSION['usr']."/". $_FILES["file"]["name"]))
                {
                    echo $_FILES["file"]["name"] . " already exists. ";
                }
                else
                {
                    $pic=($_FILES['file']['name']);
                    $type=($_FILES['file']['type']);
                    $title=$_POST['title'];
                    // Connects to your Database 
                    mysql_connect("mysql.brushup.me", "brushup13", "*?U2c!Ri") or die(mysql_error()) ; 
                    mysql_select_db("brushup_db") or die(mysql_error()) ; 
            
            
                    //$username=$_SESSION['usr']
                
                    //Writes the information to the database 
                    mysql_query("INSERT INTO uppho (photo, type, title) VALUES ('$pic', '$type', '$title')") ;
                    
                    move_uploaded_file($_FILES["file"]["tmp_name"],
                    "upload/".$_FILES["file"]["name"]);
                    
                    copy("upload/".$_FILES["file"]["name"],
                    "users/".$_SESSION['usr']."/".$_FILES["file"]["name"]);
                    
                    $dirpath = '/home/brushup13/brushup.me/users/' . $_SESSION['usr'] . '/'. $_FILES['file']['name'] . "_annotations";
		    mkdir($dirpath, 0710);
                    
                    redirect("/index.php");
                    //echo "Stored in: " . "upload/" . $_FILES["file"]["name"];
                }
            }
          }
        else
        {
            echo "Invalid file";
        }
    
    }
      
  
  
  
  
  //This is the directory where images will be saved 
 //$target = "upload/"; 
 //$target = $target . basename( $_FILES['file']['name']); 
 
 //This gets all the other information from the form 

 
 //Writes the photo to the server 
 /*if(move_uploaded_file($_FILES["file"]["name"], $target)) 
 { 
 
 //Tells you if its all ok 
 echo "The file ". basename( $_FILES['uploadedfile']['tmp_name']). " has been uploaded, and your information has been added to the directory"; 
 } 
 else { 
 
 //Gives and error if its not 
 echo "Sorry, there was a problem uploading your file."; 
 } */
?>
