
			   <?php
			   require('/home/brushup13/brushup.me/individualimage.php');
			    echo '<img style="width:600px; display: block; margin-left: auto; margin-right: auto;"
			    src=http://www.brushup.me/users/john/Screen Shot 2013-12-08 at 5.22.43 AM.png ><br>';
			    echo '<p style="text-align:center; margin-top: 20px">&copy chillandawg</p>';
			   ?>
			   