<?php
    define('INCLUDE_CHECK',true);
    require 'functions.php';
    require 'connect.php';
    
    session_name('tzLogin');
    session_set_cookie_params(2*7*24*60*60);
    session_start();
    
    if(isset($_GET['logoff']))
    {
	$_SESSION = array();
	session_destroy();
	
	header("Location: index.php");
	exit;
    }

?>

<!DOCTYPE html>
<html>

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>My Profile</title>
<link rel="stylesheet" type="text/css" href="demo.css" media="screen" />
<link rel="stylesheet" type="text/css" href="login_panel/css/slide.css" media="screen" />
<link rel="stylesheet" type="text/css" href="upload.css">
<link href="/css/styles.css" rel="stylesheet"/>
<link href="/css/style.css" rel="stylesheet"/>
<script src="/js/jquery-1.10.2.min.js"></script>
    <script src="/js/scripts.js"></script>
    
    <!--LINE THAT DOESNT WORK<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.3.2/jquery.min.js"></script>-->
    
    <!-- PNG FIX for IE6 -->
    <!-- http://24ways.org/2007/supersleight-transparent-png-in-ie6 -->
    <!--[if lte IE 6]>
        <script type="text/javascript" src="login_panel/js/pngfix/supersleight-min.js"></script>
    <![endif]-->
    
    <script src="login_panel/js/slide.js" type="text/javascript"></script>
    <?php echo $script; ?>
    
</head>
<body>
<br>
<br> 
    <div id="toppanel" style="position: fixed; margin-left: auto;">
	<div id="panel">
            
            
            <?php
			
			if(!$_SESSION['id']):
			
			?>
            		<div class="content clearfix">
			<div class="left">
				<a href ="index.php"><img src="./img/newlogo.png" style="width:220px;"></a>
				<h1>To upload or critique an artwork, please login or register!</h1>
				<h2></h2>
				<p class="grey">This panel was built on top of <a href="http://web-kreation.com/index.php/tutorials/nice-clean-sliding-login-panel-built-with-jquery" title="Go to site">Web-Kreation</a>'s amazing sliding panel.</p>
			</div>
			<div class="left">
				<!-- Login Form -->
				<form class="clearfix" action="" method="post">
					<h1>Member Login</h1>
                    
                    <?php
						
						if($_SESSION['msg']['login-err'])
						{
							echo '<div class="err">'.$_SESSION['msg']['login-err'].'</div>';
							unset($_SESSION['msg']['login-err']);
						}
					?>
					
					<label class="grey" for="username">Username:</label>
					<input class="field" type="text" name="username" id="username" value="" size="23" />
					<label class="grey" for="password">Password:</label>
					<input class="field" type="password" name="password" id="password" size="23" />
	            	<label><input name="rememberMe" id="rememberMe" type="checkbox" checked="checked" value="1" /> &nbsp;Remember me</label>
        			<div class="clear"></div>
					<input type="submit" name="submit" value="Login" class="bt_login" />
				</form>
			</div>
			<div class="left right">			
				<!-- Register Form -->
				<form action="" method="post">
					<h1>Not a member yet? Sign Up!</h1>		
                    
                    <?php
						
						if($_SESSION['msg']['reg-err'])
						{
							echo '<div class="err">'.$_SESSION['msg']['reg-err'].'</div>';
							unset($_SESSION['msg']['reg-err']);
						}
						
						if($_SESSION['msg']['reg-success'])
						{
							echo '<div class="success">'.$_SESSION['msg']['reg-success'].'</div>';
							unset($_SESSION['msg']['reg-success']);
						}
					?>
                    		
					<label class="grey" for="username">Username:</label>
					<input class="field" type="text" name="username" id="username" value="" size="23" />
					<label class="grey" for="email">Email:</label>
					<input class="field" type="text" name="email" id="email" size="23" />
					<label>A password will be e-mailed to you.</label>
					<input type="submit" name="submit" value="Register" class="bt_register" />
				</form>
			</div>
            
            <?php
			
			else:
			
			?>
			
			
			
    <div class="content clearfix">
    <div class="left">
	    <a href ="index.php"><img src="./img/newlogo.png" style="width:220px;"></a>
	    <h1>You are logged in! Upload and critique art globally!</h1>
	    <h2></h2>
	    <p class="grey">This panel was built on top of <a href="http://web-kreation.com/index.php/tutorials/nice-clean-sliding-login-panel-built-with-jquery" title="Go to site">Web-Kreation</a>'s amazing sliding panel.</p>
    </div>
            <div class="left">
            <h1 style="font-family:century gothic; font-size:25px;">Members panel</h1>
			<form action="upload.php" method="post"
                        enctype="multipart/form-data">
                            <style>.photo-button {
                            cursor: pointer;
                            float: left;
                            margin: 0px 10px 0px 0px;
                            height: 30px;
                            width: 150px;
                            border: none;
                            border-radius: 4px 4px 4px 4px;
                            background-color: #608AB0;
                            background-image: -webkit-linear-gradient(top, rgba(255, 255, 255, 0.2) 0%, rgba(255, 255, 255, 0) 100%);
                            }
                            label { display: block; }
                            </style>
			    <label><input type="text" name="title" title="title" style="color:#888;font-family:century gothic;font-size:15px;height:20px;" 
			    value="Title" onfocus="inputFocus(this)" onblur="inputBlur(this)"/></label>
			    <script>
                                function inputFocus(i){
                                    if(i.value==i.defaultValue){ i.value=""; i.style.color="#000"; }
                                }
                                function inputBlur(i){
                                    if(i.value==""){ i.value=i.defaultValue; i.style.color="#888"; }
                                }
                            </script>
                            <label><div id ="selectedFiles"> Choose a file</div><br></label>
                            <button type="button" class="photo-button"
                            onclick="document.getElementById('files').click();">
                                <span>Upload A Photo</span>
                            </button>
                            
                            <input type="file" name="file" class ="upload" id="files" style="display:none" multiple>
                            <style>
                                #selectedFiles
                                {
                                    background-color:white;
                                    width: 120px;
                                    height: 20px;
                                    font-size: 15px;
                                    font-family: century gothic;
                                }
                            </style>
                            <script>
                            var selDiv = "";
                                    
                            document.addEventListener("DOMContentLoaded", init, false);
                            
                            function init() {
                                    document.querySelector('#files').addEventListener('change', handleFileSelect, false);
                                    selDiv = document.querySelector("#selectedFiles");
                            }
                                    
                            function handleFileSelect(e) {
                                    
                                    if(!e.target.files) return;
                                    
                                    selDiv.innerHTML = "";
                                    
                                    var files = e.target.files;
                                    for(var i=0; i<files.length; i++) {
                                            var f = files[i];
                                            
                                            selDiv.innerHTML += f.name + "<br/>";

                            }
		
	}
	</script>
                        <input type="submit" name="submit" value="Post">
                        </form>
            <br>
            
            
            </div>
            
            <div class="left right">
                   <div class="container">
			<a href="http://brushup.me/myprofile.php"><p style ="font-size:15px; font-family:century gothic;">Visit Your Gallery</p></a>
		    </div><br><br>
                   <p style ="font-size:15px; font-family:century gothic; text-align: right;"><a href="?logoff">Log off</a></p>
            <br>
            </div>
            
            <?php
			endif;
			?>
		</div>
	</div> <!-- /login -->	

    <!-- The tab on top -->	
	<div class="tab">
		<ul class="login">
	    	<li class="left">&nbsp;</li>
	        <li>Hello <?php echo $_SESSION['usr'] ? $_SESSION['usr'] : 'Guest';?>!</li>
			<li class="sep">|</li>
			<li id="toggle">
				<a id="open" class="open" href="#"><?php echo $_SESSION['id']?'Open Panel':'Log In';?></a>
				<a id="close" style="display: none;" class="close" href="#">Close Panel</a>			
			</li>
	    	<li class="right">&nbsp;</li>
		</ul> 
	</div> <!-- / top -->
	
</div> <!--panel -->
	<div class="wrap">
	    <div id="header">
		<div id="navigation">
		<a id="movedown" href="index.php"><img src="./img/newlogo.png" alt="BrushUp.Me Logo" style="width:300px;"> </a>
		    
		    <a class="click" href="index.php">Home</a>
		    <a class="click" href="about.php">About</a>
		    <a class="click" href="myprofile.php">Your Gallery</a>
		    <a class="click" href="contact.php">Contact</a>
		    
		</div>
	    </div>
	    <hr width:755px>

	    
<div id = "blah">
		<div class="col1">
		    <img class ="display" src= "./img/annie.png" width = "201";><br><br>
		    <i>"Quote Quote Quote"</i><br><br>
		    <p><b>Annie Lin</b></p>
		    <i>Harvard College, 2017</i><br><br>
		    <div class ="iconbox">
			<a href ="https://www.facebook.com/the.annie.lin"><img class ="icon" src="./img/fbicon.png" width ="30";></a>
			<a href ="mailto:annielin@college.harvard.edu"><img class ="icon" src="./img/mailicon.png" width ="30";></a>
			<a href ="https://www.linkedin.com/in/theannielin"><img class ="icon" src="./img/linkedinicon.png" width ="30";></a>
		    </div>
		</div>
		<div class="col2">
		    <img class ="display" src= "./img/charles.png" width="202";><br><br>
		    <i>"Quote Quote Quote"</i><br><br>
		    <p><b>Charles Zhang</b></p>
		    <i>Harvard College, 2017</i><br><br>
		    <a href ="https://www.facebook.com/crzyboy333"><img class ="icon" src="./img/fbicon.png" width ="30";></a>
			<a href ="mailto:charleszhang@college.harvard.edu"><img class ="icon" src="./img/mailicon.png" width ="30";></a>
			<a href ="https://www.linkedin.com/"><img class ="icon" src="./img/linkedinicon.png" width ="30";></a>
		</div>
		<div class="col3">
		    <img class ="display" src= "./img/hillary.png" width="199";><br><br>
		    <i>"Quote Quote Quote"</i><br><br>
		    <p><b>Hillary Do</b></p>
		    <i>Harvard College, 2017</i><br><br>
		    <a href ="https://www.facebook.com/hillarydo.272"><img class ="icon" src="./img/fbicon.png" width ="30";></a>
			<a href ="mailto:hillaryjiado@college.harvard.edu"><img class ="icon" src="./img/mailicon.png" width ="30";></a>
			<a href ="https://www.linkedin.com/in/hillarydo"><img class ="icon" src="./img/linkedinicon.png" width ="30";></a>
		</div>


</div>
</div>
	<br><br><p style="text-align:center; margin-top: 20px">&copy chillandawg</p>
</body>

</html>
