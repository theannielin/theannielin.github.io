<!doctype html>
<html>
<div class="annotorious-editor" style="position:absolute;z-index:1">
    <form>
    <textarea class="annotorious-editor-text" placeholder="Add a Comment..." tabindex="1"></textarea>
    <div class="annotorious-editor-button-container"><a class="annotorious-editor-button annotorious-editor-button-cancel" href="javascript:void(0);" tabindex="3">Cancel</a>
    <a class="annotorious-editor-button annotorious-editor-button-save" href="javascript:void(0);" tabindex="2">Save</a></div>
    </form>
</div>
</html>