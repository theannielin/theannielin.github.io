
			   <?php
			   require('/home/brushup13/brushup.me/individualimage.php');
			    echo '<img style="width:600px; display: block; margin-left: auto; margin-right: auto;"
			    src=http://www.brushup.me/users/annielin/weety.png ><br>';
			    echo '<p style="text-align:center; margin-top: 20px">&copy chillandawg</p>';
			   ?>
			   