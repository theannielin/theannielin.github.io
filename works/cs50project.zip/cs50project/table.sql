-- phpMyAdmin SQL Dump
-- version 3.3.10.4
-- http://www.phpmyadmin.net
--
-- Host: mysql.brushup.me
-- Generation Time: Dec 08, 2013 at 08:26 AM
-- Server version: 5.1.53
-- PHP Version: 5.4.11

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

--
-- Database: `brushup_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `uppho`
--

CREATE TABLE IF NOT EXISTS `uppho` (
  `name` varchar(32) NOT NULL DEFAULT '',
  `photo` varchar(100) DEFAULT NULL,
  `type` varchar(10) NOT NULL,
  `vote` int(8) NOT NULL DEFAULT '0',
  `title` varchar(100) NOT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user` varchar(33) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=92 ;

--
-- Dumping data for table `uppho`
--

INSERT INTO `uppho` (`name`, `photo`, `type`, `vote`, `title`, `id`, `user`) VALUES
('Edvard Munch', 'scream.png', 'image/png', 21, 'The Scream', 78, 'leminay'),
('Salvador Dal�', 'Salvador-Dali-The-Persistence-of-Memory-1931.jpg', 'image/jpeg', 15, 'The Persistence of Memory', 36, 'charles'),
('Andrew Wyeth', 'Screen Shot 2013-12-08 at 3.21.41 AM.png', 'image/png', 0, 'Winter 1946', 82, 'hillary'),
('Frida Kahlo', 'fridha kahlo.jpg', 'image/jpeg', 0, 'Frida Kahlo (Self-Portrait)', 80, 'hillary'),
('Vincent Willem van Gogh', 'vangogh.jpg', 'image/jpeg', 15, 'Self-Portrait with Straw Hat', 26, 'hdo_272'),
('Unknown', 'pearl.png', 'image/png', 0, 'Pearl (Jellybean Edition)', 79, 'leminay'),
('Grant Wood', 'amgoth.png', 'image/png', -1, 'American Gothic', 87, 'davidmalan'),
('Michelangelo', 'davess.png', 'image/png', 0, 'David', 76, 'annielin'),
('M.C. Escher', 'Screen Shot 2013-12-08 at 5.22.43 AM.png', 'image/png', 0, 'Drawing Hands', 86, 'john'),
('Vincent Willem van Gogh', 'starry.png', 'image/png', 1, 'Starry Night', 88, 'davidmalan'),
('Georges-Pierre Seurat', 'Screen Shot 2013-12-08 at 5.47.39 AM.png', 'image/png', 0, 'A Sunday Afternoon', 89, 'davidmalan'),
('Sandro Botticelli', 'Screen Shot 2013-12-08 at 5.56.52 AM.png', 'image/png', 0, 'The Birth of Venus', 90, 'annielin'),
('Hans Holbein', 'Jane.png', 'image/png', 1, 'Jane Seymour', 91, 'johnsmith');
