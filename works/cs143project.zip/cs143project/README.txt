LaundryConnect
====================
Authors: Annie Lin, Amanda Boss, Billie Wei
CS143 Final project

The code for our project is contained in 2 files:
1. laundry.ino - what is flashed to the spark
2. code.gs - script to fetch data from our Spark to a Google Spreadsheet


How to run our code
--------------------
### Configuring the Spark Core itself
1. Setup and claim the Spark Core and connect it to wi-fi 
(instructions here: http://docs.spark.io/start/)

2. Signin to your Spark account.

3. Go to www.spark.io/build and click "Create a New App."

4. Copy and paste the code from our "laundry.ino" file into
the text editor section of Spark's Web IDE. Save it.

5. Click the check button on the left hand side of the Web IDE
to verify that the code doesn't have errors.

6. Flash the code to the Spark Core (top button on the Web IDE).

### Receive data from the Core
1. In Google Drive, create a new spreadsheet.

2. Go to Tools -> Script Editor. (A new window should pop up.)

3. Replace the code there with the code in "code.gs." (If using a
different Core than the one we received for our project, then replace
the URL in line 47 - for fetching data- with 
https://api.spark.io/v1/devices/YOUR-SPARK-ID/result?access_token=YOUR-ACCESS-TOKEN 
replacing the Spark ID and access token.)

4. Go to Resources -> Current Project's Triggers and fill in these parameters:
collectData - Time Driven - Minutes Timer - Every 15 minutes

5. Now, the Google Spreadsheet should fetch data from the Core every 15 minutes!


How the button works
--------------------
Every time the button is pressed, the Spark Core reads that input, posts to Twitter
that the laundry machine (which it is connected to) is currently in use. It will then 
wait 30 minutes (to allow for the laundry to finish), and then tweet that the
machine is available agian. (Additionally, this wait period will prevent again malicious
attacks from anyone who may want to press the button after the initial button push.) 

Data from the Core is stored in a connected Google Spreadsheet, which can analyze 
laundry trends. 

The physical button itself should be accompanied by signage of what the 
purpose of the button is, and when to activate it. (Prefereably very close to the laundry
"Start" button.)
